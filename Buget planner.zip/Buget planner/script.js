
import { db, collection, addDoc, getDocs, deleteDoc, doc, setDoc, getDoc, updateDoc } from "./firebase.js";

// Firestore References
const budgetDocRef = doc(db, "budget", "userBudget");
const expenseCollection = collection(db, "expenses");

// Selecting Elements
const totalAmountInput = document.getElementById("total-amount");
const expenseAmountInput = document.getElementById("user-amount");
const setBudgetButton = document.getElementById("total-amount-button");
const addExpenseButton = document.getElementById("check-amount");
const expenseTitleInput = document.getElementById("product-title");
const resetBudgetButton = document.getElementById("reset-budget-button");
const budgetError = document.getElementById("budget-error");
const expenseTitleError = document.getElementById("product-title-error");

const amountDisplay = document.getElementById("amount");
const expenseDisplay = document.getElementById("expenditure-value");
const balanceDisplay = document.getElementById("balance-amount");
const expenseList = document.getElementById("list");

let totalBudget = 0;
let totalExpenses = 0;
let editingExpenseId = null; // Stores the ID of the expense being edited

// ✅ Function to Set and Add to Budget in Firestore
setBudgetButton.addEventListener("click", async () => {
    let enteredAmount = parseFloat(totalAmountInput.value);
    if (isNaN(enteredAmount) || enteredAmount <= 0) {
        budgetError.textContent = "Value cannot be empty or negative";
        budgetError.classList.add("show");
        return;
    } else {
        budgetError.classList.remove("show");
    }

    try {
        const budgetSnapshot = await getDoc(budgetDocRef);
        let existingBudget = budgetSnapshot.exists() ? budgetSnapshot.data().totalBudget : 0;
        let updatedBudget = existingBudget + enteredAmount;

        await setDoc(budgetDocRef, { totalBudget: updatedBudget });
        totalBudget = updatedBudget;
        updateUI();
    } catch (error) {
        console.error("Error setting budget:", error);
    }

    totalAmountInput.value = "";
});
// ✅ Reset Budget & Clear Expenses
resetBudgetButton.addEventListener("click", async () => {
    try {
        // ✅ Set budget to 0 in Firestore
        await setDoc(budgetDocRef, { totalBudget: 0 });

        // ✅ Get all expense documents
        const querySnapshot = await getDocs(expenseCollection);
        
        // ✅ Delete each expense
        querySnapshot.forEach(async (doc) => {
            await deleteDoc(doc.ref);
        });

        // ✅ Update UI
        amountDisplay.innerText = "0";
        expenseDisplay.innerText = "0";
        balanceDisplay.innerText = "0";
        expenseList.innerHTML = ""; // Clear list on UI
        
        console.log("✅ Budget reset and all expenses deleted.");
    } catch (error) {
        console.error("❌ Error resetting budget:", error);
    }
});

// ✅ Function to Handle Adding an Expense
async function handleExpense() {
    let title = expenseTitleInput.value.trim();
    let amount = parseFloat(expenseAmountInput.value);

    if (!title || isNaN(amount) || amount <= 0) {
        expenseTitleError.textContent = "Expense amount cannot be empty or negative";
        expenseTitleError.classList.add("show");
        return;
    } else {
        expenseTitleError.classList.remove("show");
    }

    try {
        if (editingExpenseId) {
            // ✅ Remove old expense first
            const oldExpenseElement = document.querySelector(`[data-id="${editingExpenseId}"]`);
            if (oldExpenseElement) {
                oldExpenseElement.remove();
            }

            const oldExpenseSnapshot = await getDoc(doc(db, "expenses", editingExpenseId));
            if (oldExpenseSnapshot.exists()) {
                const oldExpenseAmount = oldExpenseSnapshot.data().amount;
                totalExpenses -= oldExpenseAmount;
            }

            await deleteDoc(doc(db, "expenses", editingExpenseId));

            // ✅ Add the new updated expense
            const newDocRef = await addDoc(expenseCollection, { title, amount });

            // ✅ Display the new expense
            displayExpense(title, amount, newDocRef.id);

            totalExpenses += amount;
        } else {
            // ✅ If adding, create a new expense in Firestore
            const docRef = await addDoc(expenseCollection, { title, amount });

            displayExpense(title, amount, docRef.id);
            totalExpenses += amount;
        }

        updateUI();
    } catch (error) {
        console.error("Error handling expense:", error);
    }

    // Reset fields
    expenseTitleInput.value = "";
    expenseAmountInput.value = "";
    addExpenseButton.textContent = "Add Expense";
    editingExpenseId = null;
}

// ✅ Attach Function to Button
addExpenseButton.addEventListener("click", handleExpense);

// ✅ Function to Display an Expense in UI
function displayExpense(title, amount, id) {
    let expenseItem = document.createElement("div");
    expenseItem.classList.add("sublist-content", "flex-space");
    expenseItem.setAttribute("data-id", id);
    expenseItem.innerHTML = `
        <p class="product">${title}</p>
        <p class="amount">${amount.toFixed(2)}</p>
        <button class="edit">✏️</button>
        <button class="delete">❌</button>`
    ;

    // ✅ Edit Expense
    expenseItem.querySelector(".edit").addEventListener("click", () => {
        expenseTitleInput.value = title;
        expenseAmountInput.value = amount;
        editingExpenseId = id;
        addExpenseButton.textContent = "Update Expense";
    });

    // ✅ Delete Expense
    expenseItem.querySelector(".delete").addEventListener("click", async () => {
        try {
            await deleteDoc(doc(db, "expenses", id));
            totalExpenses -= amount;
            updateUI();
            expenseItem.remove();
        } catch (error) {
            console.error("Error deleting expense:", error);
        }
    });

    expenseList.appendChild(expenseItem);
}

// ✅ Load Budget and Expenses from Firestore
async function loadExpenses() {
    expenseList.innerHTML = ""; 
    totalExpenses = 0;

    try {
        const budgetSnapshot = await getDoc(budgetDocRef);
        if (budgetSnapshot.exists()) {
            totalBudget = budgetSnapshot.data().totalBudget;
        }

        const querySnapshot = await getDocs(expenseCollection);
        querySnapshot.forEach((doc) => {
            let data = doc.data();
            displayExpense(data.title, data.amount, doc.id);
            totalExpenses += data.amount;
        });

        updateUI();
    } catch (error) {
        console.error("❌ Error loading data from Firestore:", error);
    }
}

// ✅ Function to Update Budget Summary in UI
function updateUI() {
    amountDisplay.innerText = totalBudget.toFixed(2);
    expenseDisplay.innerText = totalExpenses.toFixed(2);
    balanceDisplay.innerText = (totalBudget - totalExpenses).toFixed(2);
}

// ✅ Load budget and expenses when the page loads
window.onload = () => {
    loadExpenses();
}; 