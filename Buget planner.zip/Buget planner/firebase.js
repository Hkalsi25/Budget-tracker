// ✅ Import Firebase Modules
import { initializeApp } from "firebase/app";
import { 
    getFirestore, collection, addDoc, getDocs, deleteDoc, doc, setDoc, getDoc, updateDoc 
} from "firebase/firestore";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getAnalytics } from "firebase/analytics";

// ✅ Firebase Configuration
const firebaseConfig = {
    apiKey: "AIzaSyA3fJS6PhycR0NRUX66xCMDKyQNY3h2NVo",
    authDomain: "budget-planner-ab940.firebaseapp.com",
    projectId: "budget-planner-ab940",
    storageBucket: "budget-planner-ab940.appspot.com",
    messagingSenderId: "10658175769",
    appId: "1:10658175769:web:40df076cb26544a505c388",
    measurementId: "G-V858QEFWJ3"
};

// ✅ Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);  // <-- Fix: Now exporting auth properly
const analytics = getAnalytics(app);
const provider = new GoogleAuthProvider(); // Google Sign-In Provider

// ✅ Firestore Connection Check
console.log("📡 Firestore Initialized:", db);

// ✅ Export Firestore & Auth for use in other files
export { db, auth, provider, collection, addDoc, getDocs, deleteDoc, doc, setDoc, getDoc, updateDoc };
